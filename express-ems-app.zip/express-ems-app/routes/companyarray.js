var express = require('express');
var router = express.Router();



var employees=[
    {id:101,name:'Pradeep Chinchole',salary:10000.00},
    {id:102,name:'Pratik Chougule',balance:20000.00},
    {id:103,name:'Satadru Roy',balance:30000.00},
    {id:104,name:'Vidya Gahire',balance:40000.00},
    {id:105,name:'Nikhil Wanare',balance:50000.0},
 
];



/* GET all employees */
router.get('/employees', function(req, res, next) {
  res.json(employees);
});



/* GET employee by id */
router.get('/employees/:id', function(req, res, next) {
    
    var employeeId=parseInt(req.params.id);

   var employee=employees.filter(function(element,index){
           return employeeId==element.id;
       })[0];
       
    res.json(employee);

});
  

/* DELETE employee by id */
router.delete('/employees/:id', function(req, res, next) {
    
    var employeeId=parseInt(req.params.id);

   employees=employees.filter(function(element,index){
           return employeeId!=element.id;
       });
       
    res.json(employees);

});
  


/* UPDATE employee by accno */
router.put('/employees/:id', function(req, res, next) {
    
    var employeeId=parseInt(req.params.id);

    var employee=req.body;

    employees.forEach(function(element,index){
          if(element.id==employeeId)
          employees[index]=employee;
   });
    res.json(employees);

});
  

/* ADD employee */
router.post('/employees', function(req, res, next) {
    
     var employee=req.body;

      employees.push(employee);

     res.json(employees);

});
  

module.exports = router;
