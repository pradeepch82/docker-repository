var express = require('express');
var mysql=require("mysql");
var router = express.Router();



/*
create database company;
use company;
create table employee(id int primary key,name text,salary double);
insert into employee values(101,'RAM',10000.00);
insert into employee values(102,'RAHIM',20000.00);
insert into employee values(103,'DAVID',30000.00);
insert into employee values(104,'PRADEEP',40000.00);

*/

var connection=mysql.createConnection({
    host:"database",
    database:'company',
    user:'pradeep',
    password:'pradeep',
    port:3306
},function(){
   console.log("Connection established with MySQL");     
});





/* GET all employees */
router.get('/employees', function(req, res, next) {

connection.query("SELECT * FROM employee",function(err,data){
if(err) res.send(""+err);

res.json(data);

});

});



/* GET employee by id */
router.get('/employees/:id', function(req, res, next) {
    
    var employeeId=parseInt(req.params.id);
       
    connection.query("SELECT * FROM employee WHERE id=?",[employeeId],function(err,data){
        if(err) res.send(""+err);
        
        res.json(data[0]);
        
        });
    

});
  

/* DELETE employee by id */
router.delete('/employees/:id', function(req, res, next) {
    
    var employeeId=parseInt(req.params.id);

  
connection.query("DELETE FROM employee WHERE id=?",[employeeId],function(err,data){
        if(err) res.send(""+err);

        
  connection.query("SELECT * FROM employee",function(err,data){
    if(err) res.send(""+err);
    
    res.json(data);
   
    });

 });



});
  


/* UPDATE employee by id */
router.put('/employees/:id', function(req, res, next) {
    
    var employeeId=parseInt(req.params.id);

    var employee=req.body;


    connection.query("UPDATE employee SET NAME=?,salary=? WHERE id=?",[employee.name,employee.salary,employeeId],function(err,data){
        if(err) res.send(""+err);

        
  connection.query("SELECT * FROM employee",function(err,data){
    if(err) res.send(""+err);
    
    res.json(data);
   
    });

 });






    
});
  

/* ADD employee */
router.post('/employees', function(req, res, next) {
    
     var employee=req.body;

   
 connection.query("INSERT INTO employee SET ?",[employee],function(err,data){
        if(err) res.send(""+err);

        
  connection.query("SELECT * FROM employee",function(err,data){
    if(err) res.send(""+err);
    
    res.json(data);
    });

 });
/*
or
    
 connection.query("INSERT INTO ACCOUNTS VALUES(?,?,?,?)",[account.accno,account.name,account.balance,account.doc],function(err,data){
        if(err) res.send(""+err);

        
  connection.query("SELECT * FROM ACCOUNTS",function(err,data){
    if(err) res.send(""+err);
    
    res.json(data);
    });

 });


*/

    
});
  

module.exports = router;
